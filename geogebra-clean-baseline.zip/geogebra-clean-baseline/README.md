# GeoGebra Android clean baseline

Baseline académica creada desde cero para validar la paridad visual/funcional del motor GeoGebra antes de modificar cualquier comportamiento relacionado con examen.

## Qué contiene

- Un proyecto Android mínimo basado en `WebView`.
- Dos sabores de producto:
  - `graphing` -> `appName: graphing`
  - `threeD` -> `appName: 3d`
- Carga directa del `deployggb.js` oficial de GeoGebra.
- Sin overlays propios, sin menús duplicados y sin CSS que intente recrear la UI de GeoGebra.
- Workflow de GitHub Actions que genera dos APK debug independientes.

## Por qué esta baseline es deliberadamente simple

La versión anterior mezclaba simultáneamente tres capas: UI recreada, integración GeoGebra y lógica de examen. Eso hacía imposible distinguir si una regresión provenía del motor, del contenedor Android o del CSS/JavaScript adicional.

Esta baseline congela primero la UI oficial. Las modificaciones académicas deben incorporarse después en una capa separada y claramente marcada como demo/no supervisada.

## Compilar en GitHub

1. Crear un repositorio nuevo.
2. Subir el contenido de esta carpeta a la raíz.
3. Abrir **Actions**.
4. Ejecutar **Build Android APKs**.
5. Descargar el artifact `geogebra-demo-apks`.

El artifact contiene:

- `GeoGebra-Graphing-Demo.apk`
- `GeoGebra-3D-Demo.apk`

## Compilación local

Requiere Java 17, Android SDK 35 y Gradle 8.9:

```bash
gradle :app:assembleGraphingDebug :app:assembleThreeDDebug
```

## Nota de red

Esta baseline usa el JavaScript oficial desde `https://www.geogebra.org/apps/deployggb.js`. Es intencional: primero se valida que el renderer oficial se vea correctamente en Android. Una etapa posterior puede empaquetar el Math Apps Bundle para funcionamiento local/offline.

## Uso académico

Esta variante no debe presentarse como la aplicación oficial de GeoGebra ni como un entorno de examen seguro. Cualquier modo de examen modificado debe identificarse de forma inequívoca como demo/no supervisado.
