plugins {
    id("com.android.application")
}

android {
    namespace = "com.hahnhahn.geogebradmo"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.hahnhahn.geogebradmo"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "0.1.0"
    }

    flavorDimensions += "calculator"
    productFlavors {
        create("graphing") {
            dimension = "calculator"
            applicationIdSuffix = ".graphing"
            buildConfigField("String", "GGB_APP", "\"graphing\"")
        }
        create("threeD") {
            dimension = "calculator"
            applicationIdSuffix = ".threed"
            buildConfigField("String", "GGB_APP", "\"3d\"")
        }
    }

    buildFeatures {
        buildConfig = true
    }
}
