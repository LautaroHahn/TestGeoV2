# Third-party notice

This project embeds GeoGebra Math Apps for academic/non-commercial demonstration purposes.

GeoGebra source code is licensed under EUPL 1.2. GeoGebra installers, web services, language files and other assets may be subject to additional GeoGebra licensing terms. Review and preserve all applicable attribution and license notices before redistribution.

Official license information: https://www.geogebra.org/license
Official source mirror: https://github.com/geogebra/geogebra
